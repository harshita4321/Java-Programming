import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	
	@SuppressWarnings({ "unlikely-arg-type" })
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out = res.getWriter();
		res.setContentType("text/html");
		String ID = req.getParameter("ID");
		String Name = req.getParameter("Name");
		String Email = req.getParameter("Email");
		String Country = req.getParameter("Country");
		String button = req.getParameter("button");
				
		String url = "jdbc:mysql://localhost:3306/mydata";
		String username = "root";
		String password = "MysqlRoot@2021";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(url,username,password);
			int flag = 0;
			PreparedStatement ps0 = con.prepareStatement("Select id from employee;");
			ResultSet rs0 = ps0.executeQuery();
			while(rs0.next()) {
				if(ID.equals(rs0.getString(1))) {
					out.println("This ID is already taken. Refer to the data and then choose a different ID" + "<br><br>");
					flag = 1;
					RequestDispatcher rd0 = req.getRequestDispatcher("AddUser.html");
					rd0.include(req, res);
					exit();
				}
				}
			
			if (button.equals("Add Data")) {
				if(ID == null || ID.equals("") || Name == null || Name.equals("") || Email == null || Email.equals("") || Country == null || Country.equals("")) {
					out.println("Enter complete information");
					RequestDispatcher rd3 = req.getRequestDispatcher("AddUser.html");
					rd3.include(req, res);
				}
				
				else if (flag == 0){
						PreparedStatement ps = con.prepareStatement("insert into employee values(?,?,?,?)");
						
						ps.setString(1, ID);
						ps.setString(2, Name);
						ps.setString(3, Email);
						ps.setString(4, Country);
					
						ps.executeUpdate();
						out.println("Employee details added successfully." + "<br><br>");
						
						}
				
				
			} else if (button.equals("Display Data")) {
				
				PreparedStatement ps1 = con.prepareStatement("Select * from employee");
				ResultSet rs1 = ps1.executeQuery();
				
				out.println("<table border=5px>");
				
				out.println("<tr>");
				out.println("<td>" + "ID" + "</td>");
				out.println("<td>" + "Name" + "</td>");
				out.println("<td>" + "Email" + "</td>");
				out.println("<td>" + "Country" + "</td>");
				out.println("<td>" + "Action" + "</td>");
				out.println("</tr>");
				
				while(rs1.next()) {
					
					out.println("<tr>");
					
					out.println("<td read only>" + rs1.getString(1) + "</td>");
					out.println("<td>" + rs1.getString(2) + "</td>");
					out.println("<td>" + rs1.getString(3) + "</td>");
					out.println("<td>" + rs1.getString(4) + "</td>");
					out.println("</tr>");
					
				}
				
				out.println("</table>" + "<br><br>");
				out.println("<br><br>");
				
				
			} else if(button.equals("Delete Data")) {
				
				String id = req.getParameter("ID");
				if(id == null || id.equals("")) {
					RequestDispatcher rd = req.getRequestDispatcher("AddUser.html");
					out.println("Please enter your ID to delete your data");
					rd.include(req,res);
				} else {
					PreparedStatement ps2 = con.prepareStatement("Delete from employee where id = '" + id + "';");
					ps2.executeUpdate();
					out.println("Your data was successfully deleted");
				}
			} else if(button.equals("Update")) {
				String id = req.getParameter("ID");
				String n = req.getParameter("Name");
				String e = req.getParameter("Email");
				String c = req.getParameter("Country");
				if((id == null || id.equals("")) && ((n == null || n.equals("")) && (e == null || e.equals("")) && (c == null) || c.equals(""))) {
					RequestDispatcher rd = req.getRequestDispatcher("AddUser.html");
					out.println("Please enter your ID and atleast one field to update" + "<br><br>");
					rd.include(req,res);
				} else if(id != null && n!=null && (e==null || e.equals("")) && (c==null || c.equals(""))) {
					PreparedStatement ps3 = con.prepareStatement("update employee set name = '" + n + "' where id = '" + id + "';");
					ps3.executeUpdate();
					out.println("Your name was succesfully updated");
					
					} else if(id != null && (n==null || n.equals("")) && e!=null && (c==null || c.equals(""))) {
						PreparedStatement ps3 = con.prepareStatement("update employee set email = '" + e +"' where id = '" + id + "';");
						ps3.executeUpdate();
						out.println("Your email was succesfully updated");
						
					} else if(id != null && (n==null || n.equals("")) && (e==null || e.equals("")) && c!=null) {
						PreparedStatement ps3 = con.prepareStatement("update employee set country = '" + c +"' where id = '" + id + "';");
						ps3.executeUpdate();
						out.println("Your country was succesfully updated");
						
					}
				
			}
			

			
	
			
												
			out.println("<form action = 'AddUser.html'>");
			out.println("Click on the button below to add new user." + "<br><br>");
			out.println("<input type = 'submit' value = 'Login Page'>");
			out.println("</form>");		
			
		} catch(Exception ex) {
			out.println("Connection Failed");
			out.println(ex);
		}
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

}
