import java.io.*;
import java.sql.DriverManager;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.sun.jdi.connect.spi.Connection;


/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("username");
		String pass = request.getParameter("password");
		String mno = request.getParameter("mobileno");
		String email= request.getParameter("email");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","");
			if(con == null) {
				out.println("Connection Failed");
			}
			PreparedStatement ps = con.prepareStatement("insert into user values(?,?,?,?)");
			ps.setString(1, name);
			ps.setString(2, pass);
			ps.setString(3, mno);
			ps.setString(4, email);
			
			if( ps.executeUpdate() > 0) {
				out.println("Data inserted successfully");
			} else {
				out.println("Data not inserted");
			}
			
		}catch(Exception e) {
			
		}
	}

}
